package com.example.helpyfoody

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        /*
        setContent{
            SystemBarColorsDemoTheme{
                val systemUIController = rememberSystemUiController()
                val darkTheme = isSystemInDarkTheme()
                SideEffect{
                    systemUIController.setSystemBarsColor(
                        color = if(darkTheme) Color.Red else Color.Red
                    )

                }

            }
            */

        }

    }
